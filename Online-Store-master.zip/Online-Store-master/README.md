
# Online Store
An online store that sells products such as electronics, clothing, shoes, accessories, etc.

# Screenshots

## Homepage 
![App Screenshot](https://github.com/SagarPatil007/Online-Store/blob/master/Screenshot/Homepage.png?raw=true)

## Products
![App Screenshot](https://github.com/SagarPatil007/Online-Store/blob/master/Screenshot/Product%20on%20homepage.png?raw=true)


## Notification on buying a Product
![App Screenshot](https://github.com/SagarPatil007/Online-Store/blob/master/Screenshot/notification%20on%20add%20to%20cart%20product.png?raw=true)

## Cart 
![App Screenshot](https://github.com/SagarPatil007/Online-Store/blob/master/Screenshot/cart.png?raw=true)


## Navbar With Different categories 
![App Screenshot](https://github.com/SagarPatil007/Online-Store/blob/master/Screenshot/navbar%20with%20different%20categoey.png?raw=true)

## Product page by category
![App Screenshot](https://github.com/SagarPatil007/Online-Store/blob/master/Screenshot/product%20page.png?raw=true)

## Order page
![App Screenshot](https://github.com/SagarPatil007/Online-Store/blob/master/Screenshot/Order%20page.png?raw=true)

## About us
![App Screenshot](https://github.com/SagarPatil007/Online-Store/blob/master/Screenshot/about%20us%20page.png?raw=true)